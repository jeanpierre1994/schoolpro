  <!-- Vendor JS Files -->
  <script src="{{ asset('nice/assets/vendor/apexcharts/apexcharts.min.js') }}"></script>
  <script src="{{ asset('nice/assets/vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
  <script src="{{ asset('nice/assets/vendor/chart.js') }}"></script>
  <script src="{{ asset('nice/assets/vendor/echarts/echarts.min.js') }}"></script>
  <script src="{{ asset('nice/assets/vendor/quill/quill.min.js') }}"></script>
  <script src="{{ asset('nice/assets/vendor/simple-datatables/simple-datatables.js') }}"></script>
  <script src="{{ asset('nice/assets/vendor/tinymce/tinymce.min.js') }}"></script>
  <script src="{{ asset('nice/assets/vendor/php-email-form/validate.js') }}"></script>
<!-- datatable js files -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>  
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>
  <!-- Template Main JS File -->
  <script src="{{ asset('nice/assets/js/main.js') }}"></script>

     <!-- jquery personalise modal -->
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css">
     <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js"></script>
    